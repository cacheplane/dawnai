# Dawn AI Brand Assets

Official public brand assets for Dawn AI.

## Recommended usage

- Use `svg/dawn-logo-horizontal-white.svg` on dark backgrounds.
- Use `svg/dawn-logo-horizontal-black.svg` on light backgrounds.
- Use `svg/dawn-icon-white.svg` or `svg/dawn-icon-black.svg` for compact UI and logo grids.
- Use `social/dawn-social-avatar-white-on-black-1024.png` for square social avatars.

Use the files as provided. Do not stretch, recolor, redraw, or use the Dawn marks in a way that implies endorsement.

For machine-readable metadata, see `assets.json`.
